import AppListing from '../app-components/Listing/AppListing';



Vue.component('tbl-animal-listing', {
    mixins: [AppListing]
});
