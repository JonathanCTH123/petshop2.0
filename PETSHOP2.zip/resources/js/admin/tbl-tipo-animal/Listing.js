import AppListing from '../app-components/Listing/AppListing';

Vue.component('tbl-tipo-animal-listing', {
    mixins: [AppListing]
});