<a href="<?php echo e(url('admin')); ?>" class="navbar-brand">
    
    
    <h2>Petshop</h2>
    

</a>
<?php /**PATH /home/edwin/Documents/petshop/petshop2.0/resources/views/admin/layout/logo.blade.php ENDPATH**/ ?>