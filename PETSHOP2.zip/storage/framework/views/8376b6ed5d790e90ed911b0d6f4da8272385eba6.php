import AppListing from '../app-components/Listing/AppListing';

Vue.component('<?php echo e($modelJSName); ?>-listing', {
    mixins: [AppListing]
});<?php /**PATH /home/edwin/Documents/petshop/petshop2.0/vendor/brackets/admin-generator/src/../resources/views/listing-js.blade.php ENDPATH**/ ?>