<?php $__env->startSection('title', trans('admin.tbl-animal.actions.edit', ['name' => $tblAnimal->id])); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-xl">
        <div class="card">

            <tbl-animal-form
                :action="'<?php echo e($tblAnimal->resource_url); ?>'"
                :data="<?php echo e($tblAnimal->toJson()); ?>"
                :tipos_animals = <?php echo e($tipos_animal->toJson()); ?>

                v-cloak
                inline-template>

                <form class="form-horizontal form-edit" method="post" @submit.prevent="onSubmit" :action="action" novalidate>


                    <div class="card-header">
                        <i class="fa fa-pencil"></i> <?php echo e(trans('admin.tbl-animal.actions.edit', ['name' => $tblAnimal->id])); ?>

                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('admin.tbl-animal.components.form-elements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>


                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary" :disabled="submiting">
                            <i class="fa" :class="submiting ? 'fa-spinner' : 'fa-download'"></i>
                            <?php echo e(trans('brackets/admin-ui::admin.btn.save')); ?>

                        </button>
                    </div>

                </form>

        </tbl-animal-form>

        </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edwin/Documents/petshop/petshop2.0/resources/views/admin/tbl-animal/edit.blade.php ENDPATH**/ ?>